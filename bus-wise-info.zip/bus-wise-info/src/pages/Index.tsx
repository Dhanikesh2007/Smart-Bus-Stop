import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { Bus, MapPin, Clock, QrCode } from "lucide-react";
const Index = () => {
  return <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-transit py-20 px-4">
        <div className="max-w-7xl mx-auto text-center text-white">
          <Bus className="h-16 w-16 mx-auto mb-6" />
          <h1 className="text-5xl font-bold mb-4 md:text-7xl">Tracking bus    </h1>
          <p className="text-xl md:text-2xl mb-8 opacity-90">
            Your Complete Bus Transit Information System
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/routes">
              <Button size="lg" variant="secondary" className="w-full sm:w-auto">
                View Routes
              </Button>
            </Link>
            <Link to="/stops">
              <Button size="lg" variant="outline" className="w-full sm:w-auto bg-white/10 hover:bg-white/20 text-white border-white">
                Find Bus Stops
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-foreground mb-12">
            Quick Access
          </h2>
          
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            <Link to="/routes">
              <Card className="p-6 hover:shadow-elevated transition-shadow cursor-pointer h-full">
                <div className="bg-primary/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <Bus className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold text-card-foreground mb-2">Bus Routes</h3>
                <p className="text-muted-foreground">Explore all available routes and their schedules</p>
              </Card>
            </Link>

            <Link to="/stops">
              <Card className="p-6 hover:shadow-elevated transition-shadow cursor-pointer h-full">
                <div className="bg-secondary/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <MapPin className="h-6 w-6 text-secondary" />
                </div>
                <h3 className="text-xl font-semibold text-card-foreground mb-2">Bus Stops</h3>
                <p className="text-muted-foreground">Find stops near you and upcoming arrivals</p>
              </Card>
            </Link>

            <Link to="/qr-access">
              <Card className="p-6 hover:shadow-elevated transition-shadow cursor-pointer h-full">
                <div className="bg-accent/10 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <QrCode className="h-6 w-6 text-accent" />
                </div>
                <h3 className="text-xl font-semibold text-card-foreground mb-2">QR Access</h3>
                <p className="text-muted-foreground">Quick access codes for users and admins</p>
              </Card>
            </Link>

            <Link to="/admin">
              <Card className="p-6 hover:shadow-elevated transition-shadow cursor-pointer h-full">
                <div className="bg-muted w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                  <Clock className="h-6 w-6 text-muted-foreground" />
                </div>
                <h3 className="text-xl font-semibold text-card-foreground mb-2">Admin Panel</h3>
                <p className="text-muted-foreground">Manage routes, stops, and schedules</p>
              </Card>
            </Link>
          </div>
        </div>
      </section>

      {/* Real-time Updates Section */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-foreground mb-4">
            Real-Time Bus Information
          </h2>
          <p className="text-xl text-muted-foreground mb-8">
            Stay updated with live bus arrivals and route changes
          </p>
          <Link to="/stops">
            <Button size="lg">Check Live Arrivals</Button>
          </Link>
        </div>
      </section>
    </div>;
};
export default Index;