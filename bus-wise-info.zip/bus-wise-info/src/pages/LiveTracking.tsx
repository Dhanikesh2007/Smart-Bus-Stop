import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import BusMap from '@/components/BusMap';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

interface Bus {
  id: string;
  bus_number: string;
  bus_name: string;
  latitude: number | null;
  longitude: number | null;
  status: string;
  last_location_update: string | null;
}

const LiveTracking = () => {
  const [buses, setBuses] = useState<Bus[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchBuses = async () => {
    try {
      const { data, error } = await supabase
        .from('buses')
        .select('*')
        .not('latitude', 'is', null)
        .not('longitude', 'is', null);

      if (error) throw error;
      setBuses(data || []);
    } catch (error) {
      console.error('Error fetching buses:', error);
      toast({
        title: 'Error',
        description: 'Failed to fetch bus locations',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBuses();

    // Set up real-time subscription
    const channel = supabase
      .channel('bus-locations')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'buses',
        },
        (payload) => {
          console.log('Bus location updated:', payload);
          fetchBuses();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const busesWithLocation = buses.filter(
    (bus) => bus.latitude !== null && bus.longitude !== null
  ) as (Bus & { latitude: number; longitude: number })[];

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-foreground mb-2">
              Live Bus Tracking
            </h1>
            <p className="text-muted-foreground">
              Real-time location of all active buses
            </p>
          </div>
          <Button onClick={fetchBuses} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>

        {loading ? (
          <Card className="p-8 text-center">
            <p className="text-muted-foreground">Loading bus locations...</p>
          </Card>
        ) : busesWithLocation.length === 0 ? (
          <Card className="p-8 text-center">
            <MapPin className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-xl font-semibold mb-2">No buses tracking</h3>
            <p className="text-muted-foreground">
              No buses with location data available at the moment.
            </p>
          </Card>
        ) : (
          <>
            <div className="mb-6">
              <BusMap buses={busesWithLocation} />
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {busesWithLocation.map((bus) => (
                <Card key={bus.id} className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="font-semibold text-lg">{bus.bus_name}</h3>
                      <p className="text-sm text-muted-foreground">
                        Bus #{bus.bus_number}
                      </p>
                    </div>
                    <Badge
                      variant={bus.status === 'active' ? 'default' : 'secondary'}
                    >
                      {bus.status}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4" />
                    <span>
                      {bus.latitude.toFixed(6)}, {bus.longitude.toFixed(6)}
                    </span>
                  </div>
                  {bus.last_location_update && (
                    <p className="text-xs text-muted-foreground mt-2">
                      Updated:{' '}
                      {new Date(bus.last_location_update).toLocaleString()}
                    </p>
                  )}
                </Card>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default LiveTracking;
