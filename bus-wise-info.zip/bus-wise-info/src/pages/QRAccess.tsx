import { Card } from "@/components/ui/card";
import { QRCodeSVG } from "qrcode.react";
import { Shield, Users } from "lucide-react";

const QRAccess = () => {
  const publicUrl = window.location.origin;
  const adminUrl = `${window.location.origin}/admin`;

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-5xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">QR Access Codes</h1>
          <p className="text-muted-foreground">Scan to access the bus information system</p>
        </div>

        <div className="grid gap-8 md:grid-cols-2">
          <Card className="p-8 text-center shadow-card">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
              <Users className="h-8 w-8 text-primary" />
            </div>
            <h2 className="text-2xl font-bold text-card-foreground mb-2">Public Access</h2>
            <p className="text-muted-foreground mb-6">View bus schedules and routes</p>
            
            <div className="bg-white p-6 rounded-lg inline-block mb-4">
              <QRCodeSVG value={publicUrl} size={200} />
            </div>
            
            <p className="text-sm text-muted-foreground">Scan to view bus information</p>
          </Card>

          <Card className="p-8 text-center shadow-card">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent/10 mb-4">
              <Shield className="h-8 w-8 text-accent" />
            </div>
            <h2 className="text-2xl font-bold text-card-foreground mb-2">Admin Access</h2>
            <p className="text-muted-foreground mb-6">Manage bus details and schedules</p>
            
            <div className="bg-white p-6 rounded-lg inline-block mb-4">
              <QRCodeSVG value={adminUrl} size={200} />
            </div>
            
            <p className="text-sm text-muted-foreground">Scan for admin dashboard</p>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default QRAccess;
