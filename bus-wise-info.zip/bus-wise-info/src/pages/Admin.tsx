import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bus, MapPin, Clock, Settings } from "lucide-react";

const Admin = () => {
  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">Admin Dashboard</h1>
          <p className="text-muted-foreground">Manage bus routes, stops, and schedules</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Total Routes</p>
                <p className="text-3xl font-bold text-card-foreground">24</p>
              </div>
              <Bus className="h-8 w-8 text-primary" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Bus Stops</p>
                <p className="text-3xl font-bold text-card-foreground">156</p>
              </div>
              <MapPin className="h-8 w-8 text-secondary" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Active Buses</p>
                <p className="text-3xl font-bold text-card-foreground">48</p>
              </div>
              <Clock className="h-8 w-8 text-accent" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-sm">Settings</p>
                <p className="text-3xl font-bold text-card-foreground">12</p>
              </div>
              <Settings className="h-8 w-8 text-muted-foreground" />
            </div>
          </Card>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="p-6">
            <h3 className="text-xl font-semibold text-card-foreground mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <Button className="w-full justify-start" variant="outline">
                <Bus className="mr-2 h-4 w-4" />
                Add New Route
              </Button>
              <Button className="w-full justify-start" variant="outline">
                <MapPin className="mr-2 h-4 w-4" />
                Add Bus Stop
              </Button>
              <Button className="w-full justify-start" variant="outline">
                <Clock className="mr-2 h-4 w-4" />
                Update Schedule
              </Button>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-xl font-semibold text-card-foreground mb-4">Recent Updates</h3>
            <div className="space-y-3">
              <div className="text-sm">
                <p className="text-card-foreground font-medium">Route 101 updated</p>
                <p className="text-muted-foreground">2 hours ago</p>
              </div>
              <div className="text-sm">
                <p className="text-card-foreground font-medium">New stop added: City Hall</p>
                <p className="text-muted-foreground">5 hours ago</p>
              </div>
              <div className="text-sm">
                <p className="text-card-foreground font-medium">Schedule adjusted for Route 103</p>
                <p className="text-muted-foreground">1 day ago</p>
              </div>
            </div>
          </Card>
        </div>

        <Card className="p-6 mt-6 bg-accent/10 border-accent">
          <p className="text-accent-foreground text-center">
            To enable full admin functionality with database integration, we'll need to connect Lovable Cloud. This will allow you to store and manage all bus data securely.
          </p>
        </Card>
      </div>
    </div>
  );
};

export default Admin;
