import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, MapPin } from "lucide-react";

interface BusRoute {
  id: string;
  routeNumber: string;
  routeName: string;
  color: string;
  frequency: string;
  stops: number;
}

const Routes = () => {
  const routes: BusRoute[] = [
    { id: "1", routeNumber: "101", routeName: "Downtown Express", color: "blue", frequency: "15 min", stops: 12 },
    { id: "2", routeNumber: "102", routeName: "Airport Shuttle", color: "green", frequency: "30 min", stops: 8 },
    { id: "3", routeNumber: "103", routeName: "University Loop", color: "orange", frequency: "20 min", stops: 15 },
    { id: "4", routeNumber: "104", routeName: "Beach Route", color: "red", frequency: "25 min", stops: 10 },
  ];

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">Bus Routes</h1>
          <p className="text-muted-foreground">Explore all available bus routes and schedules</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {routes.map((route) => (
            <Card key={route.id} className="p-6 hover:shadow-elevated transition-shadow cursor-pointer">
              <div className="flex items-start justify-between mb-4">
                <div className={`bg-route-${route.color} text-white px-4 py-2 rounded-lg font-bold text-xl`}>
                  {route.routeNumber}
                </div>
                <Badge variant="secondary" className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {route.frequency}
                </Badge>
              </div>
              
              <h3 className="text-xl font-semibold text-card-foreground mb-3">{route.routeName}</h3>
              
              <div className="flex items-center text-muted-foreground">
                <MapPin className="h-4 w-4 mr-2" />
                <span>{route.stops} stops</span>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Routes;
