import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Clock } from "lucide-react";

interface BusStop {
  id: string;
  name: string;
  code: string;
  routes: string[];
  nextBuses: { route: string; time: string; color: string }[];
}

const BusStops = () => {
  const busStops: BusStop[] = [
    {
      id: "1",
      name: "Central Station",
      code: "CS001",
      routes: ["101", "102", "103"],
      nextBuses: [
        { route: "101", time: "5 min", color: "blue" },
        { route: "102", time: "12 min", color: "green" },
        { route: "103", time: "18 min", color: "orange" },
      ],
    },
    {
      id: "2",
      name: "Market Square",
      code: "MS002",
      routes: ["101", "104"],
      nextBuses: [
        { route: "101", time: "8 min", color: "blue" },
        { route: "104", time: "15 min", color: "red" },
      ],
    },
    {
      id: "3",
      name: "University Campus",
      code: "UC003",
      routes: ["103"],
      nextBuses: [
        { route: "103", time: "3 min", color: "orange" },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">Bus Stops</h1>
          <p className="text-muted-foreground">Find your nearest stop and upcoming arrivals</p>
        </div>

        <div className="grid gap-6">
          {busStops.map((stop) => (
            <Card key={stop.id} className="p-6 shadow-card hover:shadow-elevated transition-shadow">
              <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <MapPin className="h-5 w-5 text-primary" />
                    <h3 className="text-2xl font-semibold text-card-foreground">{stop.name}</h3>
                  </div>
                  <p className="text-muted-foreground mb-4">Stop Code: {stop.code}</p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {stop.routes.map((route) => (
                      <Badge key={route} variant="outline">
                        Route {route}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="bg-muted rounded-lg p-4 min-w-[250px]">
                  <h4 className="font-semibold text-foreground mb-3 flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    Next Arrivals
                  </h4>
                  <div className="space-y-2">
                    {stop.nextBuses.map((bus, idx) => (
                      <div key={idx} className="flex items-center justify-between">
                        <span className={`font-semibold text-route-${bus.color}`}>
                          Route {bus.route}
                        </span>
                        <span className="text-muted-foreground">{bus.time}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BusStops;
