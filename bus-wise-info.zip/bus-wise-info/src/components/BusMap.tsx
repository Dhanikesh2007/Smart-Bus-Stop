import React, { useEffect, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { Card } from './ui/card';

interface BusLocation {
  id: string;
  bus_number: string;
  bus_name: string;
  latitude: number;
  longitude: number;
  status: string;
}

interface BusMapProps {
  buses: BusLocation[];
}

const BusMap = ({ buses }: BusMapProps) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const markers = useRef<{ [key: string]: mapboxgl.Marker }>({});
  const [mapboxToken, setMapboxToken] = useState('');
  const [tokenSaved, setTokenSaved] = useState(false);

  useEffect(() => {
    const savedToken = localStorage.getItem('mapbox_token');
    if (savedToken) {
      setMapboxToken(savedToken);
      setTokenSaved(true);
    }
  }, []);

  const handleSaveToken = () => {
    if (mapboxToken) {
      localStorage.setItem('mapbox_token', mapboxToken);
      setTokenSaved(true);
    }
  };

  useEffect(() => {
    if (!mapContainer.current || !tokenSaved || !mapboxToken) return;

    mapboxgl.accessToken = mapboxToken;
    
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/streets-v12',
      center: [0, 0],
      zoom: 12,
    });

    map.current.addControl(
      new mapboxgl.NavigationControl({
        visualizePitch: true,
      }),
      'top-right'
    );

    return () => {
      map.current?.remove();
    };
  }, [tokenSaved, mapboxToken]);

  useEffect(() => {
    if (!map.current || !tokenSaved) return;

    // Remove old markers
    Object.values(markers.current).forEach(marker => marker.remove());
    markers.current = {};

    if (buses.length === 0) return;

    // Add new markers
    buses.forEach(bus => {
      if (bus.latitude && bus.longitude) {
        const el = document.createElement('div');
        el.className = 'bus-marker';
        el.innerHTML = `
          <div style="
            background-color: ${bus.status === 'active' ? '#22c55e' : '#ef4444'};
            width: 30px;
            height: 30px;
            border-radius: 50%;
            border: 3px solid white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: white;
            font-size: 12px;
          ">
            ${bus.bus_number.slice(-2)}
          </div>
        `;

        const popup = new mapboxgl.Popup({ offset: 25 }).setHTML(`
          <div style="padding: 8px;">
            <h3 style="font-weight: bold; margin-bottom: 4px;">${bus.bus_name}</h3>
            <p style="margin: 0; font-size: 14px;">Bus #${bus.bus_number}</p>
            <p style="margin: 0; font-size: 14px; color: ${bus.status === 'active' ? '#22c55e' : '#ef4444'};">
              Status: ${bus.status}
            </p>
          </div>
        `);

        const marker = new mapboxgl.Marker(el)
          .setLngLat([bus.longitude, bus.latitude])
          .setPopup(popup)
          .addTo(map.current!);

        markers.current[bus.id] = marker;
      }
    });

    // Fit map to show all buses
    if (buses.length > 0) {
      const bounds = new mapboxgl.LngLatBounds();
      buses.forEach(bus => {
        if (bus.latitude && bus.longitude) {
          bounds.extend([bus.longitude, bus.latitude]);
        }
      });
      map.current.fitBounds(bounds, { padding: 50 });
    }
  }, [buses, tokenSaved]);

  if (!tokenSaved) {
    return (
      <Card className="p-6 max-w-md mx-auto mt-8">
        <h3 className="text-lg font-semibold mb-4">Setup Mapbox</h3>
        <p className="text-muted-foreground mb-4">
          To display the map, you need a Mapbox public token. Get one for free at{' '}
          <a 
            href="https://mapbox.com/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-primary hover:underline"
          >
            mapbox.com
          </a>
        </p>
        <div className="space-y-4">
          <div>
            <Label htmlFor="mapbox-token">Mapbox Public Token</Label>
            <Input
              id="mapbox-token"
              type="text"
              placeholder="pk.eyJ1..."
              value={mapboxToken}
              onChange={(e) => setMapboxToken(e.target.value)}
            />
          </div>
          <Button onClick={handleSaveToken} className="w-full">
            Save Token
          </Button>
        </div>
      </Card>
    );
  }

  return (
    <div className="relative w-full h-[600px] rounded-lg overflow-hidden shadow-lg">
      <div ref={mapContainer} className="absolute inset-0" />
    </div>
  );
};

export default BusMap;
