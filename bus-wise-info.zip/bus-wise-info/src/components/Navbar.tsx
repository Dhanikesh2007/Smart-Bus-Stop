import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Bus, Menu, X } from "lucide-react";
import { useState } from "react";
const Navbar = () => {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const isActive = (path: string) => location.pathname === path;
  const navLinks = [{
    path: "/",
    label: "Home"
  }, {
    path: "/routes",
    label: "Routes"
  }, {
    path: "/stops",
    label: "Bus Stops"
  }, {
    path: "/live-tracking",
    label: "Live Tracking"
  }, {
    path: "/qr-access",
    label: "QR Access"
  }];
  return <nav className="sticky top-0 z-50 bg-card border-b border-border shadow-sm">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2 text-primary">
            <Bus className="h-6 w-6" />
            <span className="font-bold text-xl">Tracking bus  </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map(link => <Link key={link.path} to={link.path}>
                <Button variant={isActive(link.path) ? "default" : "ghost"} size="sm">
                  {link.label}
                </Button>
              </Link>)}
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden p-2" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && <div className="md:hidden py-4 space-y-2">
            {navLinks.map(link => <Link key={link.path} to={link.path} onClick={() => setMobileMenuOpen(false)}>
                <Button variant={isActive(link.path) ? "default" : "ghost"} className="w-full justify-start">
                  {link.label}
                </Button>
              </Link>)}
          </div>}
      </div>
    </nav>;
};
export default Navbar;