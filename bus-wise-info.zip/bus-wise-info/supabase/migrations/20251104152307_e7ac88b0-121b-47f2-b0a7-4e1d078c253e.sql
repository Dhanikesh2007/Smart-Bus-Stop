-- Add location fields to buses table
ALTER TABLE public.buses 
ADD COLUMN latitude DOUBLE PRECISION,
ADD COLUMN longitude DOUBLE PRECISION,
ADD COLUMN last_location_update TIMESTAMP WITH TIME ZONE DEFAULT now();

-- Add index for location queries
CREATE INDEX idx_buses_location ON public.buses(latitude, longitude) WHERE latitude IS NOT NULL AND longitude IS NOT NULL;